terraform {
  required_version = ">= 1.4.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
  }

  # Remote backend configuration (Storage created by pipeline)
  backend "azurerm" {
    resource_group_name  = "tfstate-rg"
    storage_account_name = "tfstateaccount12569732"
    container_name       = "tfstate"
    key                  = "terraform.tfstate"
  }
}

provider "azurerm" {
  features {}
}

# -------------------------------
# Create a Resource Group
# -------------------------------
resource "azurerm_resource_group" "rg" {
  name     = "demo-terraform-rg"
  location = "East US"
}

resource "azurerm_resource_group" "rg1" {
  name     = "demo-terraform-rg1"
  location = "East US"
}

resource "azurerm_resource_group" "rg2" {
  name     = "demo-terraform-rg2"
  location = "East US"
}


