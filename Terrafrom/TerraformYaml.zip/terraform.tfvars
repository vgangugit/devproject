resource_group_name = "rg-myproject1"
location            = "eastus"
prefix              = "myproj1"